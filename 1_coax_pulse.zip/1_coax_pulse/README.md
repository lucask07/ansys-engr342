# Day 1 Introduction: Voltage pulse in a coaxial cable

## Questions before running a simulation: 

1. Describe this circuit, think of the coax cables as wires in MultiSim.
2. What will happen?


## Now, run a transient simulation with a 3 V step from the function generator. 

1. Click the + button to the left of *coax_pulse* in the Project Manager.
2. Next, click the + button to the left of *Circuit1*
3. Right click *Analysis* and then left click *Analyze*
4. Give the simulation a few seconds to execute
5. Click the + button to the left of *Results* and then lift click on *Transient Voltage Plot 1*

## OK, now describe what you see! 
1. Observation one
2. Observation two 
3. Others?


## Finally, change the cable length and re-run 
1. Click on *P* for both coaxial cables and change to 10 mm.
2. Re-run the simulation. What changed? Why? 

